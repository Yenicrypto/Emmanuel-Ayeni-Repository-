// HELLOFOOD DASHBOARD + ORDER SYSTEM

// ADD NEW DISH
let addButton = document.getElementById("addButton");
let close = document.getElementById("close");
let save = document.getElementById("save");
let box = document.getElementById("box");
let dishImage = document.getElementById("dishImage");
let imagePreview = document.getElementById("imagePreview");

if (addButton && box) {
  addButton.onclick = function () {
    box.style.display = "flex";
  };
}

if (close && box) {
  close.onclick = function () {
    box.style.display = "none";
    resetDishForm();
  };
}

// Show the selected dish image before saving.
if (dishImage && imagePreview) {
  dishImage.onchange = function () {
    let file = dishImage.files[0];

    if (!file) {
      imagePreview.style.display = "none";
      imagePreview.src = "";
      return;
    }

    let reader = new FileReader();
    reader.onload = function (event) {
      imagePreview.src = event.target.result;
      imagePreview.style.display = "block";
    };
    reader.readAsDataURL(file);
  };
}

function resetDishForm() {
  let name = document.getElementById("dishName");
  let price = document.getElementById("dishPrice");

  if (name) name.value = "";
  if (price) price.value = "";
  if (dishImage) dishImage.value = "";
  if (imagePreview) {
    imagePreview.src = "";
    imagePreview.style.display = "none";
  }
}

function getDishes() {
  return JSON.parse(localStorage.getItem("dishes")) || [];
}

function saveDishes(dishes) {
  localStorage.setItem("dishes", JSON.stringify(dishes));
}

function renderNewDishes() {
  let dishes = document.getElementById("dishes");
  if (!dishes) return;

  let savedDishes = getDishes();

  for (let i = 0; i < savedDishes.length; i++) {
    // Do not add the same saved dish twice when the page loads.
    if (document.querySelector('[data-dish-id="' + savedDishes[i].id + '"]')) continue;

    let item = savedDishes[i];
    let newDish = document.createElement("div");
    newDish.className = "dish";
    newDish.setAttribute("data-dish-id", item.id);

    let safeName = item.name.replace(/'/g, "\\'");
    let image = item.image || "images/images(1).jpeg";

    newDish.innerHTML = `
      <img src="${image}" alt="${item.name}">
      <h3>${item.name}</h3>
      <h4>₦${item.price}</h4>
      <p>⭐ New Dish</p>
      <small>Fresh Nigerian food available on HelloFood.</small>
      <button class="cartButton" onclick="addToCart('${safeName}', ${Number(item.price)})">
        Add to Cart
      </button>
    `;

    dishes.appendChild(newDish);
  }
}

if (save) {
  save.onclick = function () {
    let name = document.getElementById("dishName").value.trim();
    let price = document.getElementById("dishPrice").value.trim();
    let file = dishImage ? dishImage.files[0] : null;

    if (name == "" || price == "") {
      alert("Please enter the dish name and price");
      return;
    }

    function finishSave(imageData) {
      let newDish = {
        id: "dish" + Date.now(),
        name: name,
        price: Number(price),
        image: imageData || "images/images(1).jpeg"
      };

      let savedDishes = getDishes();
      savedDishes.push(newDish);
      saveDishes(savedDishes);

      let dishes = document.getElementById("dishes");

      if (dishes) {
        let card = document.createElement("div");
        card.className = "dish";
        card.setAttribute("data-dish-id", newDish.id);

        let safeName = name.replace(/'/g, "\\'");

        card.innerHTML = `
          <img src="${newDish.image}" alt="${name}">
          <h3>${name}</h3>
          <h4>₦${Number(price)}</h4>
          <p>⭐ New Dish</p>
          <small>Fresh Nigerian food available on HelloFood.</small>
          <button class="cartButton" onclick="addToCart('${safeName}', ${Number(price)})">
            Add to Cart
          </button>
        `;

        dishes.appendChild(card);
      }

      resetDishForm();
      if (box) box.style.display = "none";
    }

    // If the user selected an image, save it with the dish.
    if (file) {
      let reader = new FileReader();
      reader.onload = function (event) {
        finishSave(event.target.result);
      };
      reader.readAsDataURL(file);
    } else {
      finishSave("");
    }
  };
}

// SEARCH FOR FOOD
let search = document.getElementById("search");

if (search) {
  search.onkeyup = function () {
    let word = search.value.toLowerCase();
    let dishes = document.querySelectorAll(".dish");

    for (let i = 0; i < dishes.length; i++) {
      let heading = dishes[i].querySelector("h3");
      let name = heading ? heading.innerText.toLowerCase() : "";

      dishes[i].style.display = name.includes(word) ? "block" : "none";
    }
  };
}

// SIGN UP
function fn1(event) {
  event.preventDefault();

  let nameInput = document.getElementById("name");

  if (!nameInput) return;

  let username = nameInput.value.trim();

  if (username == "") {
    alert("Please enter your name");
    return;
  }

  localStorage.setItem("username", username);
  window.location.href = "home.html";
}

// SHOW USERNAME
let userName = document.getElementById("userName");

if (userName) {
  let username = localStorage.getItem("username");

  if (username) {
    userName.innerText = username;
  }
}

/* CART
*/
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

function addToCart(name, price) {
  cart.push({
    name: name,
    price: Number(price)
  });

  saveCart();
  showCart();

  alert(name + " added to cart");
}

function showCart() {
  let cartItems = document.getElementById("cartItems");
  let cartTotal = document.getElementById("cartTotal");

  if (!cartItems || !cartTotal) return;

  cartItems.innerHTML = "";

  let total = 0;

  for (let i = 0; i < cart.length; i++) {
    let item = document.createElement("p");
    item.innerText = cart[i].name + " - ₦" + cart[i].price;
    cartItems.appendChild(item);
    total = total + Number(cart[i].price);
  }

  if (cart.length == 0) {
    cartItems.innerHTML = "<p>No food added yet.</p>";
  }

  cartTotal.innerText = "Total: ₦" + total;
}

function clearCart() {
  cart = [];
  saveCart();
  showCart();
}

/* ORDER TRACKING
   Each order stores:
   - order number
   - food items
   - total
   - exact date/time placed
   - status: On the Way -> Delivered
*/
function getOrders() {
  let orders = JSON.parse(localStorage.getItem("orders")) || [];

  // Change old status names to the new simple ones.
  for (let i = 0; i < orders.length; i++) {
    if (orders[i].status === "Order Placed" || orders[i].status === "Processing") {
      orders[i].status = "On the Way";
    }
  }

  saveOrders(orders);
  return orders;
}

function saveOrders(orders) {
  localStorage.setItem("orders", JSON.stringify(orders));
}

function placeOrder() {
  if (cart.length == 0) {
    alert("Please add food to your cart first");
    return;
  }

  let total = 0;

  for (let i = 0; i < cart.length; i++) {
    total += Number(cart[i].price);
  }

  let order = {
    id: "HF" + Date.now(),
    items: cart,
    total: total,
    placedAt: new Date().toISOString(),
    status: "On the Way"
  };

  let orders = getOrders();
  orders.push(order);
  saveOrders(orders);

  cart = [];
  saveCart();

  // No confirmation popup: go straight to the order tracking page.
  // If the order button is on the home/dashboard page,
  // take the user to the tracking page.
  window.location.href = "order.html";
}

function formatDateTime(dateString) {
  let date = new Date(dateString);

  return date.toLocaleString("en-NG", {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function moveOrder(orderId) {
  let orders = getOrders();
  let order = orders.find(function (item) {
    return item.id === orderId;
  });

  if (!order) return;

  if (order.status === "On the Way") {
    order.status = "Delivered";
    order.deliveredAt = new Date().toISOString();
  }

  saveOrders(orders);
  showOrders();
}

function showOrders() {
  let orderList = document.getElementById("orderList");

  if (!orderList) return;

  let orders = getOrders();

  orderList.innerHTML = "";

  if (orders.length == 0) {
    orderList.innerHTML = `
      <div class="empty-order">
        <h3>No orders yet</h3>
        <p>Your placed orders will appear here.</p>
      </div>
    `;
    return;
  }

  for (let i = orders.length - 1; i >= 0; i--) {
    let order = orders[i];

    let itemsText = "";
    for (let j = 0; j < order.items.length; j++) {
      itemsText += order.items[j].name;
      if (j < order.items.length - 1) {
        itemsText += ", ";
      }
    }

    let statusNumber = order.status === "Delivered" ? 2 : 1;

    let card = document.createElement("div");
    card.className = "order-card";

    let buttonText = "Order Delivered ✓";

    let deliveredText = "";

    if (order.deliveredAt) {
      deliveredText = `
        <p class="delivered-time">
          Delivered: ${formatDateTime(order.deliveredAt)}
        </p>
      `;
    }

    card.innerHTML = `
      <div class="order-top">
        <div>
          <h3>Order #${order.id}</h3>
          <p>${formatDateTime(order.placedAt)}</p>
        </div>
        <strong>₦${order.total}</strong>
      </div>

      <p class="order-food">${itemsText}</p>

      <div class="tracking">
        <div class="track-step ${statusNumber >= 1 ? "done" : ""}">
          <span>1</span>
          <p>On the Way</p>
        </div>

        <div class="track-line ${statusNumber >= 2 ? "done" : ""}"></div>

        <div class="track-step ${statusNumber >= 2 ? "done" : ""}">
          <span>2</span>
          <p>Delivered</p>
        </div>
      </div>

      <div class="order-status">
        <strong>Status: ${order.status}</strong>
        ${deliveredText}
      </div>

      ${
        order.status === "On the Way"
          ? `<button class="deliveryButton" onclick="moveOrder('${order.id}')">${buttonText}</button>`
          : `<button class="deliveryButton deliveredButton" disabled>Order Delivered ✓</button>`
      }
    `;

    orderList.appendChild(card);
  }
}

// Load saved dishes, cart/order information whenever a page opens.
renderNewDishes();
showCart();
showOrders();
