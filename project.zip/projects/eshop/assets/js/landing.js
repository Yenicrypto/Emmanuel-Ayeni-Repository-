// Renders the category shelves and gates every action (add to cart,
// buy now, view details, browse all) behind login/registration.

const catalogRoot = document.querySelector('#catalogRoot');
const gateOverlay = document.querySelector('#gateOverlay');
const gateMessage = document.querySelector('#gateMessage');
const gateDismiss = document.querySelector('#gateDismiss');
const headerActions = document.querySelector('#headerActions');

const currentUser = JSON.parse(localStorage.getItem('currentUser'));

// If someone is already logged in, swap the header CTAs for a direct
// link into the app instead of asking them to log in again.
if (currentUser && headerActions) {
  headerActions.innerHTML = `
    <span class="btn btn-ghost btn-sm" style="pointer-events:none;">Hi, ${currentUser.username}</span>
    <a href="app/dashboard.html" class="btn btn-primary"><span>Go to dashboard</span></a>
  `;
}

function openGate(message) {
  gateMessage.textContent = message || 'Create a free account or log in to add items to your cart and check out.';
  gateOverlay.classList.add('open');
}

function closeGate() {
  gateOverlay.classList.remove('open');
}

gateDismiss.addEventListener('click', closeGate);
gateOverlay.addEventListener('click', function (event) {
  if (event.target === gateOverlay) closeGate();
});

// The category shelves are now plain HTML inside #catalogRoot (see
// index.html), so this script only needs to handle the login/register
// gate that sits on top of every product action.

// Every interactive product/category action is gated: logged-in users
// go straight into the store, everyone else sees the login prompt.
document.body.addEventListener('click', function (event) {
  const trigger = event.target.closest('[data-gate]');
  if (!trigger) return;

  event.preventDefault();

  if (currentUser) {
    window.location.href = 'app/store.html';
    return;
  }

  openGate(`${trigger.dataset.gate} requires an account. Log in or register to continue.`);
});
