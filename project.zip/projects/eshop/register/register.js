// Get the HTML elements and save them in variables.
const registerForm = document.querySelector('#registerForm');
const firstNameInput = document.querySelector('#firstName');
const lastNameInput = document.querySelector('#lastName');
const emailInput = document.querySelector('#email');
const usernameInput = document.querySelector('#username');
const roleInput = document.querySelector('#role');
const passwordInput = document.querySelector('#password');
const confirmPasswordInput = document.querySelector('#confirmPassword');
const registerMessage = document.querySelector('#registerMessage');

// Run this function when the registration form is submitted.
registerForm.addEventListener('submit', function (event) {
    event.preventDefault();

    // Get the values entered by the user.
    const firstName = firstNameInput.value.trim();
    const lastName = lastNameInput.value.trim();
    const email = emailInput.value.trim().toLowerCase();
    const username = usernameInput.value.trim();
    const role = roleInput.value;
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;

    // Check that the two passwords are the same.
    if (password !== confirmPassword) {
        registerMessage.textContent = 'Passwords do not match.';
        return;
    }

    // Get saved users from localStorage.
    // If there are no users yet, use an empty array.
    const users = JSON.parse(localStorage.getItem('users')) || [];

    // Check whether the username or email is already registered.
    const userExists = users.some(function (user) {
        return user.username.toLowerCase() === username.toLowerCase() || user.email === email;
    });

    if (userExists) {
        registerMessage.textContent = 'Username or email already exists.';
        return;
    }

    // Create the new user object.
    const user = {
        firstName: firstName,
        lastName: lastName,
        email: email,
        username: username,
        password: password,
        role: role
    };

    // Add the new user to the users array.
    users.push(user);

    // Convert the array to text and save it in localStorage.
    localStorage.setItem('users', JSON.stringify(users));

    alert('Registration successful!');
    window.location.href = '../login/login.html';
});
