// Get the HTML elements and save them in variables.
const loginForm = document.querySelector('#loginForm');
const loginRole = document.querySelector('#loginRole');
const loginInput = document.querySelector('#loginInput');
const loginPassword = document.querySelector('#loginPassword');
const loginMessage = document.querySelector('#loginMessage');

// Run this function when the login form is submitted.
loginForm.addEventListener('submit', function (event) {
    event.preventDefault();

    const role = loginRole.value;
    const loginValue = loginInput.value.trim().toLowerCase();
    const password = loginPassword.value;

    if (!role) {
        loginMessage.textContent = 'Please select whether you are logging in as an Admin or a Buyer.';
        return;
    }

    // Get all registered users from localStorage.
    const users = JSON.parse(localStorage.getItem('users')) || [];

    // Find the user whose username/email and password match.
    const user = users.find(function (savedUser) {
        return (
            (savedUser.username.toLowerCase() === loginValue || savedUser.email === loginValue) &&
            savedUser.password === password
        );
    });

    if (!user) {
        loginMessage.textContent = 'Invalid username/email or password.';
        return;
    }

    // Make sure the account type they picked matches the account on file.
    if (user.role !== role) {
        loginMessage.textContent = 'That account is registered as ' + user.role + ', not ' + role + '. Please select the correct account type.';
        return;
    }

    // Save the logged-in user separately.
    localStorage.setItem('currentUser', JSON.stringify(user));

    // Open the dashboard.
    window.location.href = '../app/dashboard.html';
});
