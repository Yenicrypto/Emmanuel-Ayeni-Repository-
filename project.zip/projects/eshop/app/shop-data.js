

(function () {
    const PRODUCTS_KEY = 'eshop_products';
    const CART_KEY_PREFIX = 'eshop_cart_';
    const NOTIFICATIONS_KEY = 'eshop_notifications';
    const THEME_KEY = 'eshop_theme';

    const DEFAULT_IMAGE = '../assets/images/default-product.svg';

    
    function readHTMLProducts() {
        const cards = document.querySelectorAll('#htmlProductCatalog [data-product-id]');
        return Array.from(cards).map(function (card) {
            const image = card.querySelector('img');
            return {
                id: Number(card.dataset.productId),
                name: card.dataset.productName || '',
                category: card.dataset.productCategory || '',
                price: Number(card.dataset.productPrice) || 0,
                stock: Number(card.dataset.productStock) || 0,
                image: image && image.getAttribute('src') ? image.getAttribute('src') : DEFAULT_IMAGE,
                source: 'html'
            };
        });
    }

    function syncHTMLProducts() {
        const htmlProducts = readHTMLProducts();
        if (!htmlProducts.length) return;

        const saved = localStorage.getItem(PRODUCTS_KEY);
        let products;

        try {
            products = saved ? JSON.parse(saved) : [];
            if (!Array.isArray(products)) products = [];
        } catch (e) {
            products = [];
        }

        htmlProducts.forEach(function (htmlProduct) {
            const existing = products.find(function (product) {
                return product.id === htmlProduct.id;
            });

            if (existing) {
                existing.name = htmlProduct.name;
                existing.category = htmlProduct.category;
                existing.price = htmlProduct.price;
                existing.stock = htmlProduct.stock;
                existing.image = htmlProduct.image;
                existing.source = 'html';
            } else {
                products.push(htmlProduct);
            }
        });

        saveProducts(products);
    }

    const DEFAULT_NOTIFICATIONS = [
        { id: 1, icon: 'S', title: 'New Sale Recorded', body: 'A new sales transaction has been recorded.', time: 'Today • 10:30 AM', unread: true },
        { id: 2, icon: 'I', title: 'Stock Update', body: 'Product stock has been successfully updated.', time: 'Today • 09:45 AM', unread: true },
        { id: 3, icon: 'O', title: 'New Order Received', body: 'A new customer order has been placed.', time: 'Yesterday • 04:20 PM', unread: true },
        { id: 4, icon: 'P', title: 'Payment Successful', body: 'A customer payment was successfully recorded.', time: 'Yesterday • 01:15 PM', unread: false }
    ];

    /* ---------------- Products ---------------- */

    function getProducts() {
        syncHTMLProducts();
        const saved = localStorage.getItem(PRODUCTS_KEY);
        if (!saved) return [];
        try {
            return JSON.parse(saved);
        } catch (e) {
            return [];
        }
    }

    function saveProducts(products) {
        localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
    }

    function addProduct(product) {
        const products = getProducts();
        const newProduct = {
            id: Date.now(),
            name: product.name,
            category: product.category,
            price: Number(product.price) || 0,
            stock: Number(product.stock) || 0,
            image: product.image || DEFAULT_IMAGE,
            source: 'added'
        };
        products.push(newProduct);
        saveProducts(products);
        return newProduct;
    }

    function deleteProduct(id) {
        const products = getProducts().filter(function (p) { return p.id !== id; });
        saveProducts(products);
    }

    function formatCurrency(amount) {
        return '₦' + Number(amount || 0).toLocaleString('en-NG');
    }

    /* ---------------- Cart ---------------- */

    function cartKey(username) {
        return CART_KEY_PREFIX + username.toLowerCase();
    }

    function getCart(username) {
        if (!username) return [];
        try {
            return JSON.parse(localStorage.getItem(cartKey(username))) || [];
        } catch (e) {
            return [];
        }
    }

    function saveCart(username, cart) {
        localStorage.setItem(cartKey(username), JSON.stringify(cart));
    }

    function addToCart(username, productId, qty) {
        qty = qty || 1;
        const cart = getCart(username);
        const existing = cart.find(function (item) { return item.productId === productId; });
        if (existing) {
            existing.qty += qty;
        } else {
            cart.push({ productId: productId, qty: qty });
        }
        saveCart(username, cart);
        return cart;
    }

    function removeFromCart(username, productId) {
        const cart = getCart(username).filter(function (item) { return item.productId !== productId; });
        saveCart(username, cart);
        return cart;
    }

    function updateCartQty(username, productId, qty) {
        const cart = getCart(username);
        const item = cart.find(function (i) { return i.productId === productId; });
        if (item) {
            item.qty = Math.max(1, qty);
            saveCart(username, cart);
        }
        return cart;
    }

    function cartCount(username) {
        return getCart(username).reduce(function (sum, item) { return sum + item.qty; }, 0);
    }

    function cartTotal(username) {
        const products = getProducts();
        return getCart(username).reduce(function (sum, item) {
            const product = products.find(function (p) { return p.id === item.productId; });
            return sum + (product ? product.price * item.qty : 0);
        }, 0);
    }

    function clearCart(username) {
        saveCart(username, []);
    }

    /* ---------------- Notifications ---------------- */

    function getNotifications() {
        const saved = localStorage.getItem(NOTIFICATIONS_KEY);
        if (!saved) {
            localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(DEFAULT_NOTIFICATIONS));
            return DEFAULT_NOTIFICATIONS.slice();
        }
        try {
            return JSON.parse(saved);
        } catch (e) {
            return DEFAULT_NOTIFICATIONS.slice();
        }
    }

    function saveNotifications(list) {
        localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(list));
    }

    function unreadCount() {
        return getNotifications().filter(function (n) { return n.unread; }).length;
    }

    function markNotificationRead(id) {
        const list = getNotifications();
        const item = list.find(function (n) { return n.id === id; });
        if (item) item.unread = false;
        saveNotifications(list);
        return list;
    }

    function markAllNotificationsRead() {
        const list = getNotifications().map(function (n) {
            n.unread = false;
            return n;
        });
        saveNotifications(list);
        return list;
    }

    // Keeps the little red badge on the bell icon correct on every page.
    function updateNotificationBadge() {
        const badges = document.querySelectorAll('.notification-count');
        const count = unreadCount();
        badges.forEach(function (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? '' : 'none';
        });
    }

    /* ---------------- Theme ---------------- */

    function applyTheme() {
        const theme = localStorage.getItem(THEME_KEY);
        document.documentElement.classList.toggle('dark-mode', theme === 'dark');
    }

    function setTheme(theme) {
        localStorage.setItem(THEME_KEY, theme);
        applyTheme();
    }

    window.ShopData = {
        getProducts: getProducts,
        saveProducts: saveProducts,
        addProduct: addProduct,
        deleteProduct: deleteProduct,
        formatCurrency: formatCurrency,
        getCart: getCart,
        saveCart: saveCart,
        addToCart: addToCart,
        removeFromCart: removeFromCart,
        updateCartQty: updateCartQty,
        cartCount: cartCount,
        cartTotal: cartTotal,
        clearCart: clearCart,
        getNotifications: getNotifications,
        saveNotifications: saveNotifications,
        unreadCount: unreadCount,
        markNotificationRead: markNotificationRead,
        markAllNotificationsRead: markAllNotificationsRead,
        updateNotificationBadge: updateNotificationBadge,
        applyTheme: applyTheme,
        setTheme: setTheme,
        DEFAULT_IMAGE: DEFAULT_IMAGE
    };
})();
