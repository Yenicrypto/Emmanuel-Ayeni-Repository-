(function () {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return; // auth.js will handle the redirect

    const dashboardUser = document.querySelector('#dashboardUser');
    dashboardUser.textContent = currentUser.username;

    const roleTitle = document.querySelector('#dashboardRoleTitle');
    const description = document.querySelector('#dashboardDescription');
    const stats = document.querySelector('#dashboardStats');
    const productGrid = document.querySelector('#dashboardProductGrid');

    const products = ShopData.getProducts();
    const totalStock = products.reduce(function (sum, p) { return sum + p.stock; }, 0);

    if (currentUser.role === 'admin') {
        roleTitle.textContent = 'Admin Dashboard';
        description.textContent = 'Manage your store, stock and sales from one place.';
        stats.innerHTML =
            '<div class="stat-card"><span>Total Products</span><strong>' + products.length + '</strong></div>' +
            '<div class="stat-card"><span>Available Stock</span><strong>' + totalStock + '</strong></div>' +
            '<div class="stat-card"><span>Total Sales</span><strong>₦245,000</strong></div>' +
            '<div class="stat-card"><span>Orders</span><strong>42</strong></div>';
    } else {
        roleTitle.textContent = 'Buyer Dashboard';
        description.textContent = 'Browse products, manage your cart and account from one place.';
        stats.innerHTML =
            '<div class="stat-card"><span>Products Available</span><strong>' + products.length + '</strong></div>' +
            '<div class="stat-card"><span>Items In Cart</span><strong>' + ShopData.cartCount(currentUser.username) + '</strong></div>' +
            '<div class="stat-card"><span>My Orders</span><strong>0</strong></div>' +
            '<div class="stat-card"><span>Saved Items</span><strong>0</strong></div>';
    }

    // Show the product list for both roles, as requested — buyers get an
    // "Add to cart" button, admins get a shortcut into Stock management.
    function renderProducts() {
        productGrid.innerHTML = products.map(function (product) {
            const actionButton = currentUser.role === 'admin'
                ? '<a class="btn btn-ghost btn-sm" href="stock.html">Manage</a>'
                : '<button class="btn btn-primary btn-sm" data-add-to-cart="' + product.id + '">Add to cart</button>';

            return (
                '<div class="product-card">' +
                    '<div class="product-thumb"><img src="' + (product.image || ShopData.DEFAULT_IMAGE) + '" alt="' + product.name + '"></div>' +
                    '<h4>' + product.name + '</h4>' +
                    '<div class="product-meta">' +
                        '<span class="product-price">' + ShopData.formatCurrency(product.price) + '</span>' +
                        '<span class="product-stock">' + product.stock + ' in stock</span>' +
                    '</div>' +
                    '<div class="product-actions">' + actionButton + '</div>' +
                '</div>'
            );
        }).join('');
    }

    renderProducts();

    productGrid.addEventListener('click', function (event) {
        const button = event.target.closest('[data-add-to-cart]');
        if (!button) return;

        const productId = Number(button.dataset.addToCart);
        ShopData.addToCart(currentUser.username, productId, 1);

        const originalText = button.textContent;
        button.textContent = 'Added ✓';
        button.disabled = true;
        setTimeout(function () {
            button.textContent = originalText;
            button.disabled = false;
        }, 1200);

        // Refresh the "Items In Cart" stat card for buyers.
        if (currentUser.role !== 'admin') {
            const cards = document.querySelectorAll('#dashboardStats .stat-card');
            cards.forEach(function (card) {
                if (card.querySelector('span').textContent === 'Items In Cart') {
                    card.querySelector('strong').textContent = ShopData.cartCount(currentUser.username);
                }
            });
        }
    });
})();
