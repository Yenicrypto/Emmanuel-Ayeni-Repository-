(function () {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return; // auth.js will handle the redirect

    const stockForm = document.querySelector('#stockForm');
    const productName = document.querySelector('#productName');
    const productCategory = document.querySelector('#productCategory');
    const productImage = document.querySelector('#productImage');
    const productImagePreview = document.querySelector('#productImagePreview');
    const productQuantity = document.querySelector('#productQuantity');
    const productPrice = document.querySelector('#productPrice');
    const stockMessage = document.querySelector('#stockMessage');
    const categoryGrid = document.querySelector('#stockCategoryGrid');
    const tableBody = document.querySelector('#stockTableBody');

    const CATEGORIES = ['Food & Drinks', 'Electronics', 'Clothing', 'Home & Living'];

    function renderCategoryGrid(products) {
        categoryGrid.innerHTML = CATEGORIES.map(function (category) {
            const total = products
                .filter(function (p) { return p.category === category; })
                .reduce(function (sum, p) { return sum + p.stock; }, 0);

            return (
                '<div class="stock-card">' +
                    '<h3>' + category + '</h3>' +
                    '<p>Available stock</p>' +
                    '<strong>' + total + ' items</strong>' +
                '</div>'
            );
        }).join('');
    }

    function renderTable(products) {
        tableBody.innerHTML = products.map(function (product) {
            return (
                '<tr>' +
                    '<td><div class="stock-product-name"><img src="' + (product.image || ShopData.DEFAULT_IMAGE) + '" alt="' + product.name + '"><span>' + product.name + '</span></div></td>' +
                    '<td>' + product.category + '</td>' +
                    '<td>' + ShopData.formatCurrency(product.price) + '</td>' +
                    '<td>' + product.stock + '</td>' +
                    '<td><button class="btn btn-ghost btn-sm" data-remove-product="' + product.id + '">Remove</button></td>' +
                '</tr>'
            );
        }).join('');
    }

    function render() {
        const products = ShopData.getProducts();
        renderCategoryGrid(products);
        renderTable(products);
    }

    productImage.addEventListener('change', function () {
        const file = productImage.files[0];
        if (!file) {
            productImagePreview.src = ShopData.DEFAULT_IMAGE;
            return;
        }

        const reader = new FileReader();
        reader.onload = function (event) {
            productImagePreview.src = event.target.result;
        };
        reader.readAsDataURL(file);
    });

    render();

    stockForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const name = productName.value.trim();
        const category = productCategory.value;
        const quantity = Number(productQuantity.value);
        const price = Number(productPrice.value);
        const imageFile = productImage.files[0];

        if (!name || quantity < 0 || price < 0) {
            stockMessage.textContent = 'Please fill in every field with a valid value.';
            return;
        }

        function finishAdding(imageData) {
            ShopData.addProduct({
                name: name,
                category: category,
                stock: quantity,
                price: price,
                image: imageData || ShopData.DEFAULT_IMAGE
            });

            stockMessage.style.color = 'var(--success)';
            stockMessage.textContent = name + ' was added to stock.';
            stockForm.reset();
            productImagePreview.src = ShopData.DEFAULT_IMAGE;
            render();

            setTimeout(function () {
                stockMessage.textContent = '';
                stockMessage.style.color = '';
            }, 2500);
        }

        if (imageFile) {
            const reader = new FileReader();
            reader.onload = function (event) {
                finishAdding(event.target.result);
            };
            reader.readAsDataURL(imageFile);
        } else {
            finishAdding(ShopData.DEFAULT_IMAGE);
        }
    });

    tableBody.addEventListener('click', function (event) {
        const button = event.target.closest('[data-remove-product]');
        if (!button) return;

        ShopData.deleteProduct(Number(button.dataset.removeProduct));
        render();
    });
})();
