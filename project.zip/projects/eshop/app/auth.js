(function () {
    if (window.ShopData) ShopData.applyTheme();

    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const currentPage = window.location.pathname.split('/').pop();

    if (!currentUser) {
        window.location.href = '../login/login.html';
        return;
    }

    document.body.classList.add(currentUser.role === 'admin' ? 'admin-dashboard' : 'buyer-dashboard');

    document.querySelectorAll('#dashboardUser, .dashboard-user').forEach(function (element) {
        element.textContent = currentUser.username;
    });

    document.querySelectorAll('.role-label').forEach(function (element) {
        element.textContent = currentUser.role === 'admin' ? 'ADMIN' : 'BUYER';
    });

    document.querySelectorAll('.user-icon').forEach(function (element) {
        element.textContent = currentUser.username.charAt(0).toUpperCase();
    });

    // Buyers are never allowed into Stock or Sales pages.
    if (currentUser.role !== 'admin' && ['stock.html', 'sales.html'].includes(currentPage)) {
        window.location.href = 'dashboard.html';
        return;
    }

    document.querySelectorAll('.admin-only').forEach(function (item) {
        item.style.display = currentUser.role === 'admin' ? '' : 'none';
    });

    document.querySelectorAll('.buyer-only').forEach(function (item) {
        item.style.display = currentUser.role === 'buyer' ? '' : 'none';
    });

    document.querySelectorAll('.store-label').forEach(function (item) {
        item.textContent = currentUser.role === 'admin' ? 'Store' : 'Products';
    });

    document.querySelectorAll('.dashboard-role-title').forEach(function (item) {
        item.textContent = currentUser.role === 'admin' ? 'Admin Dashboard' : 'Buyer Dashboard';
    });

    document.querySelectorAll('.dashboard-description').forEach(function (item) {
        item.textContent = currentUser.role === 'admin'
            ? 'Manage your store, stock and sales from one place.'
            : 'Browse products, manage your cart and account from one place.';
    });

    document.querySelectorAll('#logoutLink').forEach(function (link) {
        link.addEventListener('click', function () {
            localStorage.removeItem('currentUser');
        });
    });

    if (window.ShopData) ShopData.updateNotificationBadge();
})();
