(function () {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return; // auth.js will handle the redirect

    const list = document.querySelector('#notificationList');
    const unreadCountEl = document.querySelector('#unreadCount');
    const totalCountEl = document.querySelector('#totalCount');
    const markAllReadLink = document.querySelector('#markAllRead');

    function render() {
        const notifications = ShopData.getNotifications();

        list.innerHTML = notifications.map(function (item) {
            return (
                '<div class="notification-item' + (item.unread ? ' unread' : '') + '" data-notification-id="' + item.id + '">' +
                    '<div class="notification-item-icon">' + item.icon + '</div>' +
                    '<div class="notification-content">' +
                        '<h3>' + item.title + '</h3>' +
                        '<p>' + item.body + '</p>' +
                        '<small>' + item.time + '</small>' +
                    '</div>' +
                    (item.unread ? '<span class="unread-dot"></span>' : '') +
                '</div>'
            );
        }).join('');

        unreadCountEl.textContent = notifications.filter(function (n) { return n.unread; }).length;
        totalCountEl.textContent = notifications.length;

        ShopData.updateNotificationBadge();
    }

    render();

    list.addEventListener('click', function (event) {
        const item = event.target.closest('[data-notification-id]');
        if (!item) return;

        ShopData.markNotificationRead(Number(item.dataset.notificationId));
        render();
    });

    markAllReadLink.addEventListener('click', function (event) {
        event.preventDefault();
        ShopData.markAllNotificationsRead();
        render();
    });
})();
