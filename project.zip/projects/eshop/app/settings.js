(function () {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return; // auth.js will handle the redirect

    const fullNameInput = document.querySelector('#settingsFullName');
    const usernameInput = document.querySelector('#settingsUsername');
    const saveBtn = document.querySelector('#saveSettingsBtn');
    const settingsMessage = document.querySelector('#settingsMessage');
    const themeLight = document.querySelector('#themeLight');
    const themeDark = document.querySelector('#themeDark');

    // Pre-fill the profile fields with the logged-in user's details.
    fullNameInput.value = (currentUser.firstName || '') + ' ' + (currentUser.lastName || '');
    usernameInput.value = currentUser.username;

    // Reflect the currently saved theme in the radio switches.
    const savedTheme = localStorage.getItem('eshop_theme');
    if (savedTheme === 'dark') {
        themeDark.checked = true;
    } else {
        themeLight.checked = true;
    }

    saveBtn.addEventListener('click', function () {
        const fullName = fullNameInput.value.trim();
        const newUsername = usernameInput.value.trim();

        if (!fullName || !newUsername) {
            settingsMessage.style.color = '#b3261e';
            settingsMessage.textContent = 'Full name and username cannot be empty.';
            return;
        }

        const users = JSON.parse(localStorage.getItem('users')) || [];

        // Make sure the new username isn't already taken by someone else.
        const taken = users.some(function (user) {
            return user.username.toLowerCase() === newUsername.toLowerCase() &&
                   user.username.toLowerCase() !== currentUser.username.toLowerCase();
        });

        if (taken) {
            settingsMessage.style.color = '#b3261e';
            settingsMessage.textContent = 'That username is already taken.';
            return;
        }

        const nameParts = fullName.split(' ');
        const firstName = nameParts.shift() || '';
        const lastName = nameParts.join(' ');

        // Update the matching entry in the users list.
        const userIndex = users.findIndex(function (user) {
            return user.username.toLowerCase() === currentUser.username.toLowerCase();
        });

        if (userIndex !== -1) {
            users[userIndex].username = newUsername;
            users[userIndex].firstName = firstName;
            users[userIndex].lastName = lastName;
            localStorage.setItem('users', JSON.stringify(users));
        }

        // Update the active session and header display.
        currentUser.username = newUsername;
        currentUser.firstName = firstName;
        currentUser.lastName = lastName;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));

        document.querySelectorAll('#dashboardUser, .dashboard-user').forEach(function (el) {
            el.textContent = newUsername;
        });
        document.querySelectorAll('.user-icon').forEach(function (el) {
            el.textContent = newUsername.charAt(0).toUpperCase();
        });

        settingsMessage.style.color = 'var(--success)';
        settingsMessage.textContent = 'Your changes have been saved.';

        setTimeout(function () {
            settingsMessage.textContent = '';
            settingsMessage.style.color = '';
        }, 2500);
    });

    themeLight.addEventListener('change', function () {
        if (themeLight.checked) ShopData.setTheme('light');
    });

    themeDark.addEventListener('change', function () {
        if (themeDark.checked) ShopData.setTheme('dark');
    });
})();
