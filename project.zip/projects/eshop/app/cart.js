(function () {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return; // auth.js will handle the redirect

    const emptyState = document.querySelector('#cartEmptyState');
    const cartContent = document.querySelector('#cartContent');
    const tableBody = document.querySelector('#cartTableBody');
    const totalEl = document.querySelector('#cartTotal');
    const checkoutBtn = document.querySelector('#checkoutBtn');
    const cartMessage = document.querySelector('#cartMessage');

    function render() {
        const cart = ShopData.getCart(currentUser.username);
        const products = ShopData.getProducts();

        if (cart.length === 0) {
            emptyState.style.display = '';
            cartContent.style.display = 'none';
            return;
        }

        emptyState.style.display = 'none';
        cartContent.style.display = '';

        tableBody.innerHTML = cart.map(function (item) {
            const product = products.find(function (p) { return p.id === item.productId; });
            if (!product) return '';
            const subtotal = product.price * item.qty;

            return (
                '<tr>' +
                    '<td>' + product.name + '</td>' +
                    '<td>' + ShopData.formatCurrency(product.price) + '</td>' +
                    '<td>' +
                        '<div class="qty-control">' +
                            '<button type="button" class="btn btn-ghost btn-sm" data-qty-down="' + product.id + '">−</button>' +
                            '<span>' + item.qty + '</span>' +
                            '<button type="button" class="btn btn-ghost btn-sm" data-qty-up="' + product.id + '">+</button>' +
                        '</div>' +
                    '</td>' +
                    '<td>' + ShopData.formatCurrency(subtotal) + '</td>' +
                    '<td><button type="button" class="btn btn-ghost btn-sm" data-remove="' + product.id + '">Remove</button></td>' +
                '</tr>'
            );
        }).join('');

        totalEl.textContent = ShopData.formatCurrency(ShopData.cartTotal(currentUser.username));
    }

    render();

    tableBody.addEventListener('click', function (event) {
        const upBtn = event.target.closest('[data-qty-up]');
        const downBtn = event.target.closest('[data-qty-down]');
        const removeBtn = event.target.closest('[data-remove]');

        if (upBtn) {
            const cart = ShopData.getCart(currentUser.username);
            const item = cart.find(function (i) { return i.productId === Number(upBtn.dataset.qtyUp); });
            ShopData.updateCartQty(currentUser.username, Number(upBtn.dataset.qtyUp), (item ? item.qty : 0) + 1);
            render();
        } else if (downBtn) {
            const cart = ShopData.getCart(currentUser.username);
            const item = cart.find(function (i) { return i.productId === Number(downBtn.dataset.qtyDown); });
            const newQty = (item ? item.qty : 1) - 1;
            if (newQty <= 0) {
                ShopData.removeFromCart(currentUser.username, Number(downBtn.dataset.qtyDown));
            } else {
                ShopData.updateCartQty(currentUser.username, Number(downBtn.dataset.qtyDown), newQty);
            }
            render();
        } else if (removeBtn) {
            ShopData.removeFromCart(currentUser.username, Number(removeBtn.dataset.remove));
            render();
        }
    });

    checkoutBtn.addEventListener('click', function () {
        ShopData.clearCart(currentUser.username);
        cartMessage.style.color = 'var(--success)';
        cartMessage.textContent = 'Order placed! Thanks for shopping with E-Shop.';
        render();
        setTimeout(function () {
            cartMessage.textContent = '';
            cartMessage.style.color = '';
        }, 3000);
    });
})();
