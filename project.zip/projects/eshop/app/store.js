(function () {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return; // auth.js will handle the redirect

    const tableBody = document.querySelector('#storeTableBody');
    const isBuyer = currentUser.role !== 'admin';

    function render() {
        const products = ShopData.getProducts();

        tableBody.innerHTML = products.map(function (product) {
            const status = product.stock > 0 ? 'Available' : 'Out of stock';
            const actionCell = isBuyer
                ? '<td class="buyer-only"><button class="btn btn-primary btn-sm" data-add-to-cart="' + product.id + '"' +
                  (product.stock === 0 ? ' disabled' : '') + '>Add to cart</button></td>'
                : '<td class="buyer-only"></td>';

            return (
                '<tr>' +
                    '<td><img class="store-product-image" src="' + (product.image || ShopData.DEFAULT_IMAGE) + '" alt="' + product.name + '"></td>' +
                    '<td>' + product.name + '</td>' +
                    '<td>' + product.category + '</td>' +
                    '<td>' + ShopData.formatCurrency(product.price) + '</td>' +
                    '<td>' + product.stock + '</td>' +
                    '<td><span class="status">' + status + '</span></td>' +
                    actionCell +
                '</tr>'
            );
        }).join('');

        document.querySelectorAll('.buyer-only').forEach(function (item) {
            item.style.display = isBuyer ? '' : 'none';
        });
    }

    render();

    tableBody.addEventListener('click', function (event) {
        const button = event.target.closest('[data-add-to-cart]');
        if (!button || button.disabled) return;

        const productId = Number(button.dataset.addToCart);
        ShopData.addToCart(currentUser.username, productId, 1);

        const originalText = button.textContent;
        button.textContent = 'Added ✓';
        button.disabled = true;
        setTimeout(function () {
            button.textContent = originalText;
            button.disabled = false;
        }, 1200);
    });
})();
