function sendMessage(event) {
    event.preventDefault();

    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    var whatsappNumber = "2349160836740";

    var text =
        "Hello Wise Heart Community!%0A%0A" +
        "Name: " + encodeURIComponent(name) + "%0A" +
        "Email: " + encodeURIComponent(email) + "%0A" +
        "Remark: " + encodeURIComponent(message);

    var whatsappLink = "https://wa.me/" + whatsappNumber + "?text=" + text;

    window.open(whatsappLink, "_blank");

    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("message").value = "";
}

function showFunMessage() {
    var messages = [
        "Wise hearts serve others… but wise hearts also know when it is time for a little smile! 😄",
        "Today’s community assignment: spread kindness. No deadline. No exam. 😂",
        "A strong community starts with one person saying, “How can I help?” ❤️",
        "Wisdom + service + a little laughter = a good day! 😄",
        "Plot twist: you just found the fun corner of Wise Heart Community! 🎉"
    ];

    var randomNumber = Math.floor(Math.random() * messages.length);
    document.getElementById("funText").textContent = messages[randomNumber];
}
