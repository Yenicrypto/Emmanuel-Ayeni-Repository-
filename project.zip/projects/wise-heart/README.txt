WISE HEART COMMUNITY WEBSITE - UPDATED

NEW FEATURES
1. Upcoming Initiatives section with the edited Wise Heart Community video.
2. Upcoming Initiatives section with the event flyer.
3. Contact form now opens WhatsApp to 09160836740 (using the Nigerian international format).
4. Join Community button has a # placeholder. Replace # in index.html with the real WhatsApp group/invite link.
5. A small “Community Fun” button gives a random light-hearted message.
6. Still uses simple HTML, CSS and JavaScript fundamentals.

HOW TO RUN
1. Extract the ZIP.
2. Open the folder.
3. Double-click index.html.

WHATSAPP JOIN LINK
Find this line in index.html:
<a href="#" class="button">Join the Community on WhatsApp</a>

Replace # with your real WhatsApp group/invite link when you have it.
